if not IsAddOnLoaded then IsAddOnLoaded = C_AddOns.IsAddOnLoaded end
local addon, private = ...
local Chatter = LibStub("AceAddon-3.0"):GetAddon(addon)
local mod = Chatter:NewModule("Highlights", "AceHook-3.0", "AceEvent-3.0", "LibSink-2.0")
local L = LibStub("AceLocale-3.0"):GetLocale(addon)

mod.modName = L["Highlights"]
mod.toggleLabel = L["Highlights"]

local Media = LibStub("LibSharedMedia-3.0")
local PlaySoundFile = _G.PlaySoundFile
local UnitName = _G.UnitName
local Ambiguate = _G.Ambiguate
local pairs = _G.pairs
local select = _G.select
local type = _G.type
local gsub = _G.string.gsub

-- 預設音效
local defSound = {["None"] = [[Interface\Quiet.mp3]]}
Media:Register("sound", "Loot Chime", [[Sound\interface\igLootCreature.wav]])
Media:Register("sound", "Whisper Ping", [[Sound\interface\iTellMessage.wav]])
Media:Register("sound", "Magic Click", [[Sound\interface\MagicClick.wav]])

local player = UnitName("player")
local defaults = {
    profile = {
        words = {
            [player:lower()] = player
        },
        sound = true,
        soundFile = "None",
        useSink = true,
        rerouteMessage = true,
        customChannels = {},
        sinkOptions = {},
        highlights = {}
    }
}

local options = {
    sound = {
        type = "toggle",
        name = L["Use sound"],
        desc = L["Play a soundfile when one of your keywords is said."],
        get = function() return mod.db.profile.sound end,
        set = function(info, v) mod.db.profile.sound = v end
    },
    rerouteMessage = {
        type = "toggle",
        name = L["Reroute whole message to SCT"],
        desc = L["Reroute whole message to SCT instead of just displaying 'who said keyword in channel'"],
        order = 22,
        get = function() return mod.db.profile.rerouteMessage end,
        set = function(info, v) mod.db.profile.rerouteMessage = v end,
        disabled = function() return not mod.db.profile.useSink end
    },
    addWord = {
        type = "input",
        name = L["Add Word"],
        desc = L["Add word to your highlight list"],
        get = function() end,
        set = function(info, v)
            if v:match("^%s*$") then return end
            mod.db.profile.words[v:lower()] = v
        end
    },
    removeWord = {
        type = "select",
        name = L["Remove Word"],
        desc = L["Remove a word from your highlight list"],
        get = function() end,
        set = function(info, v) mod.db.profile.words[v:lower()] = nil end,
        values = function() return mod.db.profile.words end,
        confirm = function(info, v) return L["Remove this word from your highlights?"] end
    },
    config = {
        type = "group",
        name = L["Custom Channel Sounds"],
        args = {}
    }
}
function mod:OnInitialize()
    self.db = Chatter.db:RegisterNamespace("Highlight", defaults)
    self:AddCustomChannels(GetChannelList())
    self:SetSinkStorage(self.db.profile.sinkOptions)
    options.output = self:GetSinkAce3OptionsDataTable()
end

local words
function mod:OnEnable()
    words = self.db.profile.words
    self:RegisterEvent("CHAT_MSG_SAY", "ParseChat")
    self:RegisterEvent("CHAT_MSG_GUILD", "ParseChat")
    self:RegisterEvent("CHAT_MSG_OFFICER", "ParseChat")
    self:RegisterEvent("CHAT_MSG_INSTANCE_CHAT", "ParseChat")
    self:RegisterEvent("CHAT_MSG_INSTANCE_CHAT_LEADER", "ParseChat")
    self:RegisterEvent("CHAT_MSG_PARTY", "ParseChat")
    self:RegisterEvent("CHAT_MSG_PARTY_LEADER", "ParseChat")
    self:RegisterEvent("CHAT_MSG_RAID", "ParseChat")
    self:RegisterEvent("CHAT_MSG_RAID_LEADER", "ParseChat")
    self:RegisterEvent("CHAT_MSG_RAID_WARNING", "ParseChat")
    self:RegisterEvent("CHAT_MSG_WHISPER", "ParseChat")
    self:RegisterEvent("CHAT_MSG_BN_WHISPER", "ParseChat")
    self:RegisterEvent("CHAT_MSG_YELL", "ParseChat")
    self:RegisterEvent("CHAT_MSG_CHANNEL", "ParseChat")
    self:RegisterEvent("CHAT_MSG_CHANNEL_NOTICE")

    self:AddCustomChannels(GetChannelList())
    self:AddCustomChannels(
        "SAY", "CHAT_MSG_SAY", nil,
        "GUILD", "CHAT_MSG_GUILD", nil,
        "OFFICER", "CHAT_MSG_OFFICER", nil,
        "INSTANCE_CHAT", "CHAT_MSG_INSTANCE_CHAT", nil,
        "INSTANCE_CHAT_LEADER", "CHAT_MSG_INSTANCE_CHAT_LEADER", nil,
        "PARTY", "CHAT_MSG_PARTY", nil,
        "PARTY_LEADER", "CHAT_MSG_PARTY_LEADER", nil,
        "RAID", "CHAT_MSG_RAID", nil,
        "RAID_LEADER", "CHAT_MSG_RAID_LEADER", nil,
        "RAID_WARNING", "CHAT_MSG_RAID_WARNING", nil,
        "WHISPER", "CHAT_MSG_WHISPER", nil,
        "BN_WHISPER", "CHAT_MSG_BN_WHISPER", nil,
        "YELL", "CHAT_MSG_YELL", nil
    )

    self.urlcopy = Chatter:GetModule("URL Copy")
    mod.db.profile.useSink = true
end
function mod:CHAT_MSG_CHANNEL_NOTICE(evt, notice)
    self:AddCustomChannels(GetChannelList())
end

function mod:AddCustomChannels(...) 
	for i = 1, select("#", ...), 3 do 
		local id, name = select(i, ...) 
		local safeName = tostring(name or "") 
		local safeId = tostring(id or "") 
		if safeName ~= "" and not options[safeName:gsub(" ", "_")] then 
			options.config.args[safeName:gsub(" ", "_")] = { 
					type = "group", 
					name = safeName, 
					args = {
                    sound = {
                        type = "select",
                        name = L["Use sound"],
                        values = Media:HashTable("sound") or {},
                        dialogControl = "LSM30_Sound",
                        desc = L["Play a sound when a message is received in this channel"],
                        order = type(id) == "number" and 103 or 102,
                        get = function() return self.db.profile.customChannels[safeId] or "None" end, 
						set = function(info, v) 
							self.db.profile.customChannels[safeId] = v
                            local soundPath = Media:Fetch("sound", v)
                            if soundPath then PlaySoundFile(soundPath) end
                        end
                    },
                    highlight = {
                        type = "toggle",
                        name = L["Enable"].." "..L["Highlights"],
                        desc = L["Alerts you when someone says a keyword or speaks in a specified channel."],
                        get = function()
                            return self.db.profile.highlights[safeId]
                        end,
                        set = function(info, v)
                            self.db.profile.highlights[safeId] = v
                        end
                    }
                }
            }
        end
    end
end
function mod:ParseChat(evt, msg, sender, ...)
    local senderName = tostring(sender or "")
    if senderName == player then return end
    
    local filters = C_ChatInfo and C_ChatInfo.GetMessageEventFilters and C_ChatInfo.GetMessageEventFilters(evt)
    if filters then
        for i, filterFunc in ipairs(filters) do
            local filtered, new_message = filterFunc(DEFAULT_CHAT_FRAME, evt, msg, senderName, ...)
            if filtered then
                return
            end
            msg = new_message or msg
        end
    end

    local lmsg = msg and msg:lower() or ""
    for k, v in pairs(words) do
        local found = false
        if type(k) == "string" and lmsg:find(k, 1, true) then
            found = true
        end
        if found then
            if evt == "CHAT_MSG_CHANNEL" then
                local num = select(7, ...)
                local safeNum = tostring(num or "")
				local hl = self.db.profile.highlights[safeNum]
                if hl then
                    self:Highlight(msg, senderName, k, num, evt)
                    return
                end
            else
                local e = evt:gsub("^CHAT_MSG_", "")
                local safeE = tostring(e or "")
				local hl = self.db.profile.highlights[safeE]
                if hl then
                    self:Highlight(msg, senderName, k, e, evt)
                    return
                end
            end
        end
    end
end
function mod:Highlight(msg, who, what, where, event)
    if not where or #where == 0 then
        where = tostring(where or event:gsub("^CHAT_MSG_", ""))
    end
    if self.db.profile.sound then
        if self.db.profile.customChannels[where] ~= nil then
            local soundPath = Media:Fetch("sound", self.db.profile.customChannels[where])
            if soundPath then PlaySoundFile(soundPath) end
        end
    end
    if self.db.profile.useSink then
        if mod.db.profile.rerouteMessage then
            msg = tostring(msg or "")
            self:Pour((L["[%s] %s: %s"]):format(where, who, msg), 1, 1, 0, nil, 24, "OUTLINE", false)
        else
            self:Pour((L["%s said '%s' in %s"]):format(who, what, where), 1, 1, 0, nil, 24, "OUTLINE", false)
        end
    end
end

function mod:Info()
    return L["Alerts you when someone says a keyword or speaks in a specified channel."]
end

function mod:GetOptions()
    return options
end
